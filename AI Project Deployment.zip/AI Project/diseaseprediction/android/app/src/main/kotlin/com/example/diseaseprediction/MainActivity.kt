package com.example.diseaseprediction

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
